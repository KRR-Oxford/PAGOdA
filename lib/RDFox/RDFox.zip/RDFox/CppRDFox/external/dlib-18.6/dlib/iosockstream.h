// Copyright (C) 2012  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_IOSOCkSTREAM_H___
#define DLIB_IOSOCkSTREAM_H___

#include "iosockstream/iosockstream.h"


#endif // DLIB_IOSOCkSTREAM_H___


