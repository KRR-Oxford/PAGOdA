To compile this project in Eclipse, one needs to determine where the JNI includes are, and what is the suffix for the
shared libraries on your target platform. These steps can be accomplished as follows.

* Go to "Window -> Preferences -> C/C++ Build -> Build Variables".
* Define variable SHARED_LIBRARY_SUFFIX as "dylib" on Mac OS X and "so" on Linux. The variable should be of type 'String'.
* Define variable RDFOX_LINK_FLAGS = "-framework CoreServices" on Mac OS X. The variable should be of type 'String'.
* Define variable TARGET_OS as "mac" on Mac OS X and "linux" on Linux. The variable should be of type 'String'.
* Define variable JNI_INCLUDE_1 and JNI_INCLUDE_2 to point to the two directories in Java where the include files lie.
  Both variables should be of type 'Path'.

On Mac, the JNI includes are here:

+ JNI_INCLUDE_1: /Library/Java/JavaVirtualMachines/jdk1.7.0_51.jdk/Contents/Home/include
+ JNI_INCLUDE_2: /Library/Java/JavaVirtualMachines/jdk1.7.0_51.jdk/Contents/Home/include/darwin

On Linux, the JNI includes are here:

the value for JNI_INCLUDE_1 can be found by searching for jni.h on top-level

+ JNI_INCLUDE_1: /usr/lib/jvm/java-1.7.0-openjdk/include/
+ JNI_INCLUDE_2: /usr/lib/jvm/java-1.7.0-openjdk/include/linux/

